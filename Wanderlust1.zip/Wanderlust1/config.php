<?php
$host = "localhost"; // Change if using a remote server
$dbname = "wtaos";
$username = "root";
$password = " ";

$conn = new mysqli('localhost', 'root', '', 'wtaos');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
