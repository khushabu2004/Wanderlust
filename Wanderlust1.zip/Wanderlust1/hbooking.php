<?php
// Ensure the script runs only when a POST request is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate that form fields exist
    $hotel = isset($_POST["hotel"]) ? $_POST["hotel"] : null;
    $customer_name = isset($_POST["customer_name"]) ? $_POST["customer_name"] : null;
    $rooms = isset($_POST["rooms"]) ? $_POST["rooms"] : null;
    $checkin = isset($_POST["checkin"]) ? $_POST["checkin"] : null;
    $checkout = isset($_POST["checkout"]) ? $_POST["checkout"] : null;
    $payment = isset($_POST["payment"]) ? $_POST["payment"] : null;

    // Ensure no fields are empty
    if (!$hotel || !$customer_name || !$rooms || !$checkin || !$checkout || !$payment) {
        die("Error: All fields are required.");
    }

    // Connect to the database
    $conn = new mysqli("localhost", "root", " ", "wtaos");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO bookings (hotel, customer_name, room_type, checkin, checkout, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $hotel, $customer_name, $rooms, $checkin, $checkout, $payment);

    // Execute query
    if ($stmt->execute()) {
        echo "Booking successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connections
    $stmt->close();
    $conn->close();
} else {
    die("Invalid request.");
}
?>
