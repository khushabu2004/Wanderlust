<?php
include 'config.php';

$query = $_GET['query'];
$sql = "SELECT name FROM destinations WHERE name LIKE '%$query%' LIMIT 5";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
?>
