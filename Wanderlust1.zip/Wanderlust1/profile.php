<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full-name'];
    $age = $_POST['age'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $medical_issues = $_POST['medical-issues'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $postal_address = $_POST['postal-address'];
    $residential_address = $_POST['residential-address'];

    $sql = "INSERT INTO profile (full_name, age, birthdate, gender, medical_issues, phone, email, postal_address, residential_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sisssssss", $full_name, $age, $birthdate, $gender, $medical_issues, $phone, $email, $postal_address, $residential_address);

    if ($stmt->execute()) {
        echo "Profile saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
