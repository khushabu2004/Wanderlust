<?php
include 'config.php';

$name = $_GET['name'];
$sql = "SELECT * FROM destinations WHERE name = '$name'";
$result = $conn->query($sql);

$data = $result->fetch_assoc();
echo json_encode($data);
?>
