// Locations aur unke background images ka array
const locations = [
    { name: "Maharashtra", image: "image/maharashtra.jpg" },
    { name: "Kashmir", image: "image/kashmir.jpg" },
    { name: "Goa", image: "image/goa.jpeg" },
    { name: "Kerala", image: "image/kerala.jpg" },
    { name: "Assam", image: "image/aasam.jpg" },
    { name: "Gujarat", image: "image/gujrat.jpg" },
    { name: "Karnataka", image: "image/karanatak.jpg" },
    { name: "Meghalaya", image: "image/meghaly.jpg" },
    { name: "Himachal Pradesh", image: "image/himachal.jpg" },
    { name: "Bihar", image: "image/bihar.jpeg" },
    { name: "Jharkhand", image: "image/jharkhand.jpg" }
];

let index = 0; // Pehla location index

function changeBackground() {
    const locationName = locations[index].name;
    const changeContentElement = document.querySelector(".changecontent");

    // Location name change karna
    changeContentElement.textContent = locationName;

    // Background image change karna
    document.querySelector(".home").style.backgroundImage = 
        `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url('${locations[index].image}')`;

    // Text color ko yellow karna
    changeContentElement.style.color = "yellow";

    // Next location ke liye index badhao
    index = (index + 1) % locations.length; // Loop mein wapas start hone ke liye
}


// Function to toggle menu visibility
document.querySelector('.hamburger-menu').addEventListener('click', function() {
    const menu = document.querySelector('.menu');
    menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
});
// Har 3 second mein background change karega
setInterval(changeBackground, 3000);


// Handle itinerary form submission
document.getElementById("plannerForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const destination = document.getElementById("destination").value;
    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;
    const activity = document.getElementById("activity").value;

    if (!destination || !startDate || !endDate || !activity) {
        alert("Please fill all fields");
        return;
    }

    // Create itinerary item
    const itineraryItem = document.createElement("li");
    itineraryItem.innerHTML = `
        <strong>Destination:</strong> ${destination} <br>
        <strong>From:</strong> ${startDate} <strong>To:</strong> ${endDate} <br>
        <strong>Activity:</strong> ${activity}
    `;

    // Add item to itinerary list
    document.getElementById("itineraryList").appendChild(itineraryItem);

    // Reset form fields
    document.getElementById("plannerForm").reset();
});

// Handle booking form submission
document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const hotel = document.getElementById("hotel").value;
    const flight = document.getElementById("flight").value;
    const transport = document.getElementById("transport").value;

    if (!hotel || !flight || !transport) {
        alert("Please fill all booking details");
        return;
    }

    alert("Booking Confirmed!\nHotel: " + hotel + "\nFlight: " + flight + "\nTransport: " + transport);
    
    // Reset booking form
    document.getElementById("bookingForm").reset();
});


// Toggle hamburger menu visibility
const hamburger = document.querySelector('.hamburger-menu');
const menu = document.querySelector('.menu');

hamburger.addEventListener('click', function() {
    menu.classList.toggle('show');
    hamburger.classList.toggle('open');
});

// Close menu when clicking outside
window.onclick = function(event) {
    if (!event.target.matches('.hamburger-menu') && !event.target.matches('.menu')) {
        menu.classList.remove('show');
        hamburger.classList.remove('open');
    }
};

function searchDestinations() {
    let query = document.getElementById("search").value;
    if (query.length < 2) return;

    fetch("search.php?query=" + query)
        .then(response => response.json())
        .then(data => {
            let suggestions = data.map(item => 
                `<p onclick="getDestinationDetails('${item.name}')">${item.name}</p>`
            ).join("");
            document.getElementById("suggestions").innerHTML = suggestions;
        });
}

function getDestinationDetails(name) {
    fetch("getDetails.php?name=" + name)
        .then(response => response.json())
        .then(data => {
            document.getElementById("result").innerHTML = `
                <h2>${data.name}</h2>
                <p>${data.description}</p>
                <img src="${data.image}" width="300">
            `;
        });
}
